<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User_controller extends CI_Controller {
	
	public function __construct(){
		
		parent::__construct();
		//$this->load->helper('url');
		$this->load->library('session');
		//$this->session->keep_flashdata('message'); 
	

	
	}
	
	
	
	
   public function index(){
	 
	$this->load->view('Welcome_message');
   }
   
   public function logout(){

     unset($_SESSION);
     $this->session->set_flashdata("logout","you have successfully logout");
     
		  echo $this->session->flashdata("logout"); 
		    	   
      session_destroy();
     redirect("/user_controller/login");

     

   }




   
   public function login(){


         
	  
		 
		  $this->form_validation->set_rules('username','Username','required');
		 
		 
		   $this->form_validation->set_rules('dob','DOB','required');
	   
	     if($this->form_validation->run()==TRUE){
			 
			$username=$_POST['username'];
            $DOB=$_POST['dob'];
		
            //check user in database ;
		    $this->db->select('*');
			$this->db->from('tbluser');
           $this->db->where(array('name'=>$username,'DOB'=>$DOB));			
		

			 $query = $this->db->get();
			 
			 $user = $query->row();
			
			 //if user exists
			 //$user is an object so it has null vaalue not (true or flase) but if support only T or F so convert it we need isset() function ; 
			 if(isset($user->Email)){
				 
				 $this->session->set_flashdata("success","successfully log in");
				 //set session variable
				$_SESSION['user_logged']=TRUE;
                $_SESSION['username']=$user->name;
                $_SESSION['id']=$user->id;
                $_SESSION['mobile']=$user->mobileNo;
                $_SESSION['dob']=$user->DOB;
                $_SESSION['email']=$user->Email;
                $_SESSION['pincode']=$user->pincode;			
				 
			  //redirect to profile page
               redirect("/user/profile"); 			  
				 
			 }
			 else{   
			 	 $this->session->set_flashdata("error",
			         "Invalid  no such account found ");

			   
			     redirect("/user_controller/login");

                 
			 }
			 
			 
		 }

	
		 
	   $this->load->view('loginpage');
	  
   }
   
   
   
   
	
	public function register()
	    {
		
		
		 if(isset($_POST['submit']))
		 {
		   $this->form_validation->set_rules('username','Username','required');
		   $this->form_validation->set_rules('mobile','Mobile no','required');
		   $this->form_validation->set_rules('dob','DOB','required');
		   $this->form_validation->set_rules('email','email','required');
		   $this->form_validation->set_rules('pincode','pincode','required');
		   
		   if($this->form_validation->run()==TRUE)
		   {
			   
			   echo  'form_validated';
			   
			   //add users to database;
			   
			   $data=array(
			       'name'=>$_POST['username'],
				   'mobileNo'=>$_POST['mobile'],
			       'DOB'=>$_POST['dob'],
			       'Email'=>$_POST['email'],
			       'pincode'=>$_POST['pincode'],
			    
			   );
			   
			   $this->db->insert('tbluser',$data);
			   
			   $this->session->set_flashdata("success","your account has been successfully created. you can login now");
			   redirect("/user_controller/register");
		   }
		  
		   
		   
	   }
	   
		
	   $this->load->view('registration');
	   
	   }
}

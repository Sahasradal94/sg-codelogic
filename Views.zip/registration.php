<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
<head>
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
     <meta name="viewport" content="width=device-width,initial-scale=1"/>
	 <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
     <title>My Form</title>
	 
     <link type = "text/css" rel="stylesheet"
	 href="<?php echo base_url(); ?>assets/css/bootstrap.min.css"   >
  
	 
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type = 'text/javascript'></script>

	
</head>
<style>
  
 .customDiv{
  margin-top:100px;
  margin-left:25px;

 }
</style>


<body>
   <div class="row">
    <div class="col-lg-5 col-md-3 col-sm-2 col-lg-offset-2">
      <div class="h1">Registration page</div>
         <p>Welcome to this website .Please fill in the details!</p>
		 <?php if(isset($_SESSION['success'])) {?>
		    <div class="alert alert-success" ><?php echo $_SESSION['success'];?>
		    	
		    </div>
		 
		 <?php } ?>
			
        <?php echo validation_errors('<div class="alert alert-danger">','</div>');?>		 
		 
	  <form action= "" method="POST">	 
      <div class="form-group">
	
         <label for="username" class="label-default">Username:</label>
         <input class="form-control" name="username" id="username"
            type="text"	/>
      </div>
     
	 <div class="form-group">
	     <label for="mobile no" class="label-default">Mobile No:</label>
         <input class="form-control" name="mobile" id="mobile" type="tel" />
     </div>
      
	  <div class="form-group">
	     <label for="dob" class="label-default">DOB:</label>
         <input class="form-control" name="dob" id="dob" type="date" />
       </div>
      
	  <div class="form-group">
	  <label for="email" class="label-default">email:</label>
         <input class="form-control" name="email" id="email" type="text"
		 pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" />
      </div>
		 

       <div class="form-group">
	     <label for="pincode" class="label-default">pincode:</label>
         <input class="form-control" name="pincode" id="pincode" type="text" pattern="([0-9]){6}"/>
       
	   </div> 

         
		  <hr/>
		 
            <button class="btn btn-primary" name="submit">Submit:</button>
	   </form>	  
    </div>
    <div class="col-lg-3 col-md-3 col-sm-1 customDiv">
      <h4> already gave an account </h4>
      <a href="<?php base_url();?>login">login now</a>

    </div>
  </div>
   <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    
   
    <!-- Include all compiled plugins (below), or include individual files as needed
     -->
     
</body>
</html>
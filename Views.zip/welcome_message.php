<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
<head>
     <meta charset="utf-8" />
     <meta name="viewport" content="width=device-width,initial-scale=1"/>
	 <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
     <title>My Form</title>
	 
     <link type = "text/css" rel="stylesheet"
	 href="<?php echo base_url(); ?>assets/css/bootstrap.min.css"   >
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
       
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqBootstrapValidation/1.3.6/jqBootstrapValidation.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type = 'text/javascript'></script>

	
</head>
<style>
  
 .customDiv{
  margin-top:100px;
  margin-left:25px;

 }


</style>



<body>
    <div class="container">
    <div class="row customDiv">
    <div class="col-lg-7 col-md-3 col-sm-2 col-lg-offset-2">
      <div class="h1">New Website!!</div>
         <div class="h2"> Welcome to this website!</div>
               <h2>Please Register</h2>

         
		  <hr/>
		 
        
            <a class="btn btn-info" role="button"
            href="<?php base_url();?>index.php/user_controller/register">Register now</a>
            
        
	   	  
      </div>
    </div>    
        

   </div>     
     <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
   
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
  
</body>
</html>
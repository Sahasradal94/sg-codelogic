<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html>
<head>
     <meta charset="utf-8" />
     <meta name="viewport" content="width=device-width,initial-scale=1"/>
	 <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
     <title>profilepage</title>
	 
     <link type = "text/css" rel="stylesheet"
	 href="<?php echo base_url(); ?>assets/css/bootstrap.min.css"   >
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
       
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jqBootstrapValidation/1.3.6/jqBootstrapValidation.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js" type = 'text/javascript'></script>

	
</head>



<body>
  
    <div class="col-lg-10 col-lg-offset-2">
      <div class="h1">welcome to your profile</div>
         
		 <?php  if(isset($_SESSION['success'])) {?>
		    <div class="alert alert-success" >
		    	<?php echo $_SESSION['success']; ?>
		    	
		    </div>
		   
		 <?php }   ; ?>

		 <div class="row">
              <div class="col-lg-7 col-md-4 col-sm-2">
		        <h2>hello! <?php  echo $_SESSION['username'];?></h2>	
		  	
       	         
	          </div>
	          <div class="col-lg-5 col-md-4 col-sm-6">
	          	  
                  <div class="img-thumbnail">
                   <img src=""  alt="profile pic"
                   width="180px" height="150px" />
                   </div>
                  
              </div> 
	    </div>
	    <div class="row">
	      <div class="col-lg-6 col-md-5 col-sm-6"> 
	    	  <h4>please find accounts details:</h4> 
           </div>
           <div class="col-lg-3 col-md-4 col-sm-8">
        	 <a href="<?php echo base_url(); ?>index.php/user_controller/logout">
	             logout</a>
            </div>
         </div>  
        <hr/>
        <h4>User ID:  <?php echo $_SESSION['id'];?></h3> </br>
       <h4>User name: <?php echo $_SESSION['username'];?></h3> </br>
       <h4>mobile no: <?php echo $_SESSION['mobile'];?></h3> </br>
       <h4>Email:     <?php echo $_SESSION['email'];?></h3> </br>
       <h4>Pincode:   <?php echo $_SESSION['pincode'];?></h3> </br>
       <h4>DOB:       <?php echo $_SESSION['dob'];?></h3> </br>
		  

        


	 
         
		  <hr/>
		 
           
	 
    </div>
    
     <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
   
    
    <!-- Include all compiled plugins (below), or include individual files as needed -->
  
</body>
</html>